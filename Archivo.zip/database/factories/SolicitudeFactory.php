<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Solicitude;
use Faker\Generator as Faker;

$factory->define(Solicitude::class, function (Faker $faker) {
    return [
			
    ];
});
