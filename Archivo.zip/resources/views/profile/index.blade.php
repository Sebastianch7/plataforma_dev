@extends('appb')
@section('content')
<h1>hola</h1>
@endcontent