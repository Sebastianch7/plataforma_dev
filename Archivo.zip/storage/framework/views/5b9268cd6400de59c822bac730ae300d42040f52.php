<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-6 col-md-12 mx-auto">
    <div class="card">
      <div class="card-header">
        <h1>Editar usuario</h1>
      </div>
      <div class="card-body">

        <form action="<?php echo e(route('user.updateuser', $users)); ?>" method="POST">
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="idNumber">Identificación</label>
              <input class="form-control" value="<?php echo e($users->idNumber); ?>" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="phone">Número de contacto</label>
              <input type="phone" class="form-control" id="phone" value="<?php echo e($users->phone); ?>" readonly>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="name">Nombres</label>
              <input type="text" class="form-control" id="name" value="<?php echo e($users->name); ?>" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="lastname">Apellidos</label>
              <input type="text" class="form-control" id="lastname" value="<?php echo e($users->lastname); ?>" readonly>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="email">email</label>
              <input type="email" class="form-control" id="email" value="<?php echo e($users->email); ?>" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="email">Estado</label>
              <select type="email" class="form-control" id="state" value="<?php echo e($users->state); ?>" name="state" required>
                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="float-right">
          <button type="submit" class="btn btn-primary">Actualizar</button>
          <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Cancelar</a>
        </div>
        </div>
      </form>
    </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/plataforma_dev/resources/views/user/edituser.blade.php ENDPATH**/ ?>