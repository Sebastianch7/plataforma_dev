<?php $__env->startSection('content'); ?>


<nav class="navbar navbar-light">
  <div class="container-fluid">
    <a href="<?php echo e(route('service.create')); ?>" class="btn btn-primary">Registrar servicio</a>
    <form class="d-flex" action="<?php echo e(route('service.search')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <input class="form-control" name="data" type="search" placeholder="Consultar" aria-label="Search">
      <button class="btn btn-primary" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
  </div>
</nav>

<div class="row justify-content-center">
  <div class="col-lg-12 col-md-12 col-sm-12">
    <div class="card">
      <div class="card-body overflow-auto">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible" role="alert">
          <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <h4>Listado de servicios</h4>
        <table class="table table-hover table-sm">
          <caption>Total de registros <?php echo e($cant); ?> </caption>
          <thead class="table bg-primary text-white">
            <tr>
              <th>#</th>
              <th>Nombre</th>
              <th>Descripción</th>
              <th>Valor</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php 
              $pos=1;
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
              <td class="align-middle"><?php print $pos++ ?></td>
              <td class="align-middle"><?php echo e($service->name); ?></td>
              <td class="align-middle"><?php echo e($service->description); ?></td>
              <td class="align-middle"><?php echo e(number_format($service->price,2)); ?></td>
              <td>
                <a href="<?php echo e(route('service.edit', $service->id)); ?>" class="btn btn-primary">Editar</a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="4">No se encontraron registros.</td>
              <td>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <div class="mx-auto text-center">
        <?php echo e($services->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/plataforma_dev/resources/views/service/index.blade.php ENDPATH**/ ?>