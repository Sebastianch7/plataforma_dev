<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-6 col-md-12 mx-auto">
    <div class="card">
      <div class="card-header">
        <h1>Registrar servicio</h1>
      </div>
      <div class="card-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          - <?php echo e($error); ?><br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('service.store' )); ?>" method="POST">
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="name">Nombre</label>
              <input type="text" class="form-control" name="name">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="description">Descripción <small>(200 caractéres maximo)</small></label>
              <textarea class="form-control" name="description" maxlength="200"></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-12">
                <label for="price">Precio</label>
                <input type="phone" class="form-control" name="price">
            </div>
          </div>
          <?php echo csrf_field(); ?>
          <div class="float-right">
            <button type="submit" class="btn btn-primary">Registrar</button>
          </form>
          <a class="btn btn-secondary" href="<?php echo e(route('service.index')); ?>">Cancelar</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/plataforma_dev/resources/views/service/create.blade.php ENDPATH**/ ?>