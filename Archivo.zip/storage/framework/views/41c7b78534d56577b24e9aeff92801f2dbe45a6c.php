<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-6 col-md-12 mx-auto">
    <div class="card">
      <div class="card-header">
        <h1>Registrar solicitud</h1>
      </div>
      <div class="card-body">
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              - <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
        <form action="<?php echo e(route('solicitude.store' )); ?>" method="POST">
          <div class="form-row">
            <p>A continuación ingrese los datos del candidato.</p>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="name">Nombres*</label>
              <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
            </div>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="lastname">Apellidos*</label>
              <input type="text" class="form-control" name="lastname" value="<?php echo e(old('lastname')); ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="typeDocument">Tipo de identificación*</label>
              <select class="form-control" name="typeDocument" value="<?php echo e(old('typeDocument')); ?>">
                <?php $__empty_1 = true; $__currentLoopData = $typesDocument; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $typeDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($typeDocument->id); ?>"><?php echo e($typeDocument->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option>No se encontraron tipos de documento</option>
                <?php endif; ?>
              </select>
            </div>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="idNumber">Número de identificación*</label>
              <input type="phone" class="form-control" name="idNumber" value="<?php echo e(old('idNumber')); ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="phone">Número de teléfono*</label>
              <input type="phone" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>">
            </div>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="cellphone">Número de celular*</label>
              <input type="phone" class="form-control" name="cellphone" value="<?php echo e(old('cellphone')); ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="departament">Departamento*</label>
              <select class="form-control" id="departament" name="departament">
                <option>Seleccione...</option>
                <?php $__empty_1 = true; $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($departament->id); ?>"><?php echo e($departament->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option>No se encontraron ciudades</option>
                <?php endif; ?>
              </select>
            </div>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="city">Ciudad de residencia*</label>
              <select class="form-control" id="city" name="city">
                <option>Seleccione...</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="mail">Correo electrónico*</label>
              <input type="mail" class="form-control" name="mail" value="<?php echo e(old('mail')); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="address">Dirección de residencia*</label>
              <input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="postulate">Cargo postulado*</label>
              <input type="mail" class="form-control" name="postulate" value="<?php echo e(old('postulate')); ?>">
            </div>
            <div class="form-group col-md-6">
              <label for="role">Servicio</label>
              <select class="form-control" name="service" value="<?php echo e(old('service')); ?>">
                <option>Seleccione...</option>
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option>No se encontraron servicios</option>
                <?php endif; ?>
              </select>
            </div>
          </div>
          <?php echo csrf_field(); ?>
          <div class="float-right">
            <button type="submit" class="btn btn-primary">Registrar</button>
      </form>
            <a class="btn btn-secondary" href="<?php echo e(route('solicitude.index')); ?>">Cancelar</a>
          </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/plataforma_dev/resources/views/solicitude/create.blade.php ENDPATH**/ ?>