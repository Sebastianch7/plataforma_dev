<?php $__env->startSection('content'); ?>

<div class="row">
  <div class="col-lg-6 col-md-12 mx-auto">
    <div class="card">
      <div class="card-header">
        <h1>Asignar solicitud</h1>
      </div>
      <div class="card-body">
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              - <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
        <form action="<?php echo e(route('solicitude.update', $solicitude->id)); ?>" method="POST">
          <div class="form-row">
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="name">Número de identificación*</label>
              <input type="text" class="form-control" value="<?php echo e($solicitude->idNumber); ?>" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="rpostulate">Cargo postulado*</label>
              <input type="mail" class="form-control" name="rpostulate" value="<?php echo e($solicitude->postulate); ?>" readonly>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="rname">Nombres*</label>
              <input type="text" class="form-control" name="rname" value="<?php echo e($solicitude->name); ?>" readonly>
            </div>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="rlastname">Apellidos*</label>
              <input type="text" class="form-control" name="rlastname" value="<?php echo e($solicitude->lastname); ?>" readonly>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="rphone">Número de teléfono*</label>
              <input type="phone" class="form-control" name="rphone" value="<?php echo e($solicitude->phone); ?>" readonly>
            </div>
            <div class="form-group col-lg-6 col-md-12 col-sm-12">
              <label for="rcellphone">Número de celular*</label>
              <input type="phone" class="form-control" name="rcellphone" value="<?php echo e($solicitude->mobile); ?>" readonly>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-6">
              <label for="rmail">Correo electrónico*</label>
              <input type="mail" class="form-control" name="rmail" value="<?php echo e($solicitude->mail); ?>" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="raddress">Dirección de residencia*</label>
              <input type="text" class="form-control" name="raddress" value="<?php echo e($solicitude->address); ?>" readonly>
            </div>
            <div class="form-group col-md-6">
              <label for="idState">Estado*</label>
              <select type="text" class="form-control" name="idState">
                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="float-right">
            <button type="submit" class="btn btn-primary" onclick="confirm('¿Desea modificar los datos en pantalla?')">Aceptar</button>
      </form>
            <a class="btn btn-secondary" href="<?php echo e(route('solicitude.index')); ?>">Cancelar</a>
          </div>
        </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/plataforma_dev/resources/views/solicitude/editsolicitude.blade.php ENDPATH**/ ?>