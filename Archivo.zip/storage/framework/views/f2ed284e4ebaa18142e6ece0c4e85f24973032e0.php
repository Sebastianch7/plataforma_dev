<?php $__env->startSection('content'); ?>


<nav class="navbar navbar-light">
  <div class="container-fluid">
    <a href="<?php echo e(route('solicitude.create')); ?>" class="btn btn-primary">Registrar solicitud</a>
    <form class="d-flex" action="<?php echo e(route('solicitude.search')); ?>" method="POST">
      <!-- <?php echo csrf_field(); ?> -->
      <input class="form-control" name="data" type="search" placeholder="Consultar" aria-label="Search">
      <button class="btn btn-primary" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
  </div>
</nav>

<div class="row justify-content-center">
  <div class="col-md-12">
    <div class="card">
      <div class="card-body overflow-auto">
        <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
          <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <h4>Listado de solicitudes</h4>
        <table class="table table-hover table-sm">
          <caption>Total de registros <?php echo e($cant); ?> </caption>
          <thead class="table bg-primary text-white">
            <tr>
              <th>#</th>
              <th>Candidato</th>
              <th>Cédula</th>
              <th>Teléfono</th>
              <th>Celular</th>
              <th>Correo</th>
              <th>Dirección</th>
              <th>Cargo postulación</th>
              <th>Estado</th>
              <th>Servicio</th>
              <!-- <th>password</th> -->
              <th>acción</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $pos=1;
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitude): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td class="align-middle"><?php print $pos++ ?></td>
              <td class="align-middle"><?php echo e($solicitude->name); ?> <?php echo e($solicitude->lastname); ?></td>
              <td class="align-middle"><?php echo e($solicitude->idNumber); ?></td>
              <td class="align-middle"><?php echo e($solicitude->phone); ?></td>
              <td class="align-middle"><?php echo e($solicitude->mobile); ?></td>
              <td class="align-middle"><?php echo e($solicitude->mail); ?></td>
              <td class="align-middle"><?php echo e($solicitude->address); ?></td>
              <td class="align-middle"><?php echo e($solicitude->postulate); ?></td>
              <td class="align-middle"><?php echo e($solicitude->state); ?></td>
              <td class="align-middle"><?php echo e($solicitude->service); ?></td>
              <!-- Estado 3 es igual a solicitado, unico que permite modificar la información o cancelar -->
              <?php if($solicitude->idState == 4 && (auth()->user()->role == 1 || auth()->user()->role == 2 || auth()->user()->role == 5)): ?>
              <td>
                <a href="<?php echo e(route('solicitude.edit', $solicitude->id)); ?>" class="btn btn-primary">Editar</a>
              </td>
              <?php elseif($solicitude->idState == 4 && (auth()->user()->role == 1 || auth()->user()->role == 2 || auth()->user()->role == 3)): ?>
              <td>
                <a href="<?php echo e(route('solicitude.editsolicitude', $solicitude->id)); ?>" class="btn btn-primary">Asignar</a>
              </td>
              <?php elseif($solicitude->idState == 5  && (auth()->user()->role == 1 || auth()->user()->role == 2 || auth()->user()->role == 4)): ?>
              <td>
                <a href="<?php echo e(route('solicitude.editsolicitude', $solicitude->id)); ?>" class="btn btn-primary">Gestionar</a>
              </td>
              <?php elseif($solicitude->idState == 6  && (auth()->user()->role == 1 || auth()->user()->role == 2 || auth()->user()->role == 4)): ?>
              <td>
                <a href="<?php echo e(route('solicitude.editsolicitude', $solicitude->id)); ?>" class="btn btn-primary">Gestionar</a>
              </td>
              <?php elseif($solicitude->idState == 7  && (auth()->user()->role == 1 || auth()->user()->role == 2 || auth()->user()->role == 3)): ?>
              <td>
                <a href="<?php echo e(route('solicitude.editsolicitude', $solicitude->id)); ?>" class="btn btn-primary">Verificar</a>
              </td>
              <?php elseif($solicitude->idState == 8): ?>
              <td>
                <a href="" class="btn btn-success">Descargar informe</a>
              </td>
              <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6"></td>
              <td>
              </td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <div class="mx-auto text-center">
        <?php echo e($solicitudes->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/plataforma_dev/resources/views/solicitude/index.blade.php ENDPATH**/ ?>