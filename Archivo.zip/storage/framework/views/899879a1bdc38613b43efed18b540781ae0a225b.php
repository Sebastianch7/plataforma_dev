<!-- Footer -->
<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span><a href="https://sebastianchb.com">©Sebastianchb 2021</a></span>
		</div>
	</div>
</footer>
<!-- End of Footer --><?php /**PATH /Applications/MAMP/htdocs/plataforma_dev/resources/views/layouts/footer.blade.php ENDPATH**/ ?>