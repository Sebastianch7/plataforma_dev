<?php	
	header('location: public/')
?>